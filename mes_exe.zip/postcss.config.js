module.exports = {
    plugins: {
        autoprefixer: {}
    },
};
