<template lang="pug">
    #app
        router-view
</template>
