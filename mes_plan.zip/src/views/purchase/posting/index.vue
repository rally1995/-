<template lang="pug">
    router-view
</template>

<script>
export default {
    name: 'posting'
};
</script>

<style scoped>

</style>
