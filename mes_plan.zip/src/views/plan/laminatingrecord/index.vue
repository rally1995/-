<template lang="pug">
    div 层压工序生产记录
</template>
<script>

</script>
<style lang="stylus" scoped>

</style>