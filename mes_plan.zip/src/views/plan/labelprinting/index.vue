<template lang="pug">
    div 标签打印
</template>
<script>

</script>
<style lang="stylus" scoped>

</style>