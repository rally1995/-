<template lang="pug">
    router-view
</template>

<script>
export default {
    name: 'basic'
};
</script>

<style scoped>

</style>
