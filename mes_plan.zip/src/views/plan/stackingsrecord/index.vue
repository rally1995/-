<template lang="pug">
    div 叠制工序生产记录
</template>
<script>

</script>
<style lang="stylus" scoped>

</style>