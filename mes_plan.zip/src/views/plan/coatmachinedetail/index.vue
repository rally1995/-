<template lang="pug">
    div 涂覆机生产耗能明细
</template>
<script>

</script>
<style lang="stylus" scoped>

</style>