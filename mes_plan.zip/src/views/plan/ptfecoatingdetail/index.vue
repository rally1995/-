<template lang="pug">
    div PTFE上胶机生产状态明细
</template>
<script>

</script>
<style lang="stylus" scoped>

</style>