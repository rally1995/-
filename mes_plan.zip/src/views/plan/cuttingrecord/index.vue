<template lang="pug">
    div 裁切工序生产记录
</template>
<script>

</script>
<style lang="stylus" scoped>

</style>