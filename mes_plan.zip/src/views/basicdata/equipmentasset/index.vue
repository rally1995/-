<template lang="pug">
    router-view
</template>

<script>
export default {
    name: 'equipmentasset'
};
</script>

<style scoped>

</style>