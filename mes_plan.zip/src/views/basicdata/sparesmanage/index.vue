<template lang="pug">
    router-view
</template>

<script>
export default {
    name: 'sparesmanage'
};
</script>

<style scoped>

</style>