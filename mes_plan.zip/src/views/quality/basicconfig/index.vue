<template lang="pug">
    router-view
</template>

<script>
export default {
    name: 'basicconfig'
};
</script>

<style scoped>

</style>
