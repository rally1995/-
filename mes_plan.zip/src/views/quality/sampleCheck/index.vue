<template lang="pug">
    router-view
</template>

<script>
export default {
    name: 'sampleCheck'
};
</script>

<style scoped>

</style>