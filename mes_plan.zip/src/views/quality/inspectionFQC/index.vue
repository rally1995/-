<template lang="pug">
    router-view
</template>

<script>
export default {
    name: 'inspectionFQC'
};
</script>

<style scoped>

</style>