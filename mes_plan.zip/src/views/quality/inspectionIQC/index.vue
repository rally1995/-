<template lang="pug">
    router-view
</template>

<script>
export default {
    name: 'inspectionIQC'
};
</script>

<style scoped>

</style>