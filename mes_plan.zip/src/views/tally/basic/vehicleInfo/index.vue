<template lang="pug">
    router-view
</template>

<script>
export default {
    name: 'vehicleInfo'
};
</script>

<style scoped>

</style>
