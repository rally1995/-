<template lang="pug">
    router-view
</template>

<script>
export default {
    name: 'layout'
};
</script>

<style scoped>

</style>