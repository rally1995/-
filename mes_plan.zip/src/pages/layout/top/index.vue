<template lang="pug">
    .header
        tabs
        user-info
</template>
<script src="./script.js"></script>
<style src="./style.styl" scoped lang="stylus"></style>
