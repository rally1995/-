import userInfo from './userInfo.vue';
import tabs from './tabs.vue';
export default {
    components: {
        userInfo,
        tabs
    }
};
